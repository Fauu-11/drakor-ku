# K-STREAM dengan CodeIgniter 4

## Menjalankan aplikasi

Pastikan PHP 8.2+ dan Composer tersedia, lalu jalankan:

```powershell
composer install
Copy-Item env .env
php spark serve
```

Buka `http://localhost:8080`.

Route aplikasi:

- `/` - katalog K-STREAM
- `/player?id={id}&eps={index}` - pemutar episode
- `/admin` - konsol admin

## Konfigurasi Supabase

Isi nilai berikut di `.env`:

```ini
supabase.url = 'https://your-project.supabase.co'
supabase.key = 'your-publishable-anon-key'
```

### Rating pengguna dan komentar

Jalankan file berikut satu kali melalui **Supabase SQL Editor**:

```text
database/supabase_community.sql
```

Script tersebut membuat:

- `drakor_ratings` untuk rating 1-5 per perangkat pengguna
- `drakor_comments` untuk komentar pada drama dan episode
- `drakor_rating_summary` untuk rata-rata rating yang ringan dibaca katalog

Sebelum script dijalankan, rating dan komentar tetap berfungsi sebagai fallback lokal di browser, tetapi belum dapat terlihat oleh pengguna lain.

History tontonan dan posisi resume disimpan di `localStorage` masing-masing perangkat agar tidak membutuhkan login dan tidak menambah request saat video diputar.

Untuk deployment, ubah juga `app.baseURL` sesuai domain aplikasi dan arahkan document root web server ke folder `public`.

## Struktur utama

```text
app/Controllers/Pages.php
app/Views/pages/home.php
app/Views/pages/player.php
app/Views/pages/admin.php
public/manifest.json
public/sw.js
```
