# K-STREAM — Premium OTT Streaming Platform

K-STREAM adalah aplikasi streaming drakor berbasis **CodeIgniter 4** dengan **Supabase** sebagai backend data, **TailwindCSS** untuk UI, dan dukungan **PWA**.

## Fitur

- Katalog drama, film, dan serial
- Rating dari pengguna, bukan admin
- Komentar per episode
- History tontonan dan resume posisi
- Player modern dengan DASH / embed / MP4 / YouTube support
- Watchlist lokal
- Admin dashboard untuk kelola judul dan episode

## Genre

Genre yang tersedia sekarang mencakup:

`Drama`, `Movie`, `Series`, `Romance`, `Action`, `Thriller`, `Comedy`, `Fantasy`, `Mystery`, `Crime`, `Horror`, `Historical`, `Medical`, `School`, `Family`, `Slice of Life`, `Sci-Fi`, `Supernatural`, `Legal`, `Political`, `Youth`, `Melodrama`

## Struktur

- `/` - katalog
- `/player?id={id}&eps={index}` - player
- `/admin` - admin panel

## Setup

1. Install dependency:

```powershell
composer install
```

2. Copy env:

```powershell
Copy-Item env .env
```

3. Isi `.env`:

```ini
app.baseURL = 'http://localhost:8080/'
supabase.url = 'https://your-project.supabase.co'
supabase.key = 'your-publishable-anon-key'
```

4. Jalankan app:

```powershell
php spark serve
```

## Supabase SQL

Jalankan file ini satu kali di Supabase SQL Editor:

- [database/supabase_community.sql](database/supabase_community.sql)

File tersebut membuat:

- `drakor_ratings`
- `drakor_comments`
- `drakor_rating_summary`

## Catatan

- Rating dan komentar tetap punya fallback lokal jika tabel komunitas belum dibuat.
- History dan posisi video disimpan di `localStorage` perangkat pengguna.
- Document root deployment harus mengarah ke folder `public`.
