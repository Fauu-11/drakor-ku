<?php

namespace Tests\Support;

use CodeIgniter\Test\CIUnitTestCase;
use CodeIgniter\Test\FeatureTestTrait;

final class PagesTest extends CIUnitTestCase
{
    use FeatureTestTrait;

    public function testHomePageLoads(): void
    {
        $result = $this->get('/');

        $result->assertStatus(200);
        $result->assertSee('K-STREAM');
    }

    public function testPlayerPageLoads(): void
    {
        $result = $this->get('/player');

        $result->assertStatus(200);
        $result->assertSee('Streaming Premium');
        $result->assertSee('Beri Rating Kamu');
        $result->assertSee('Komentar');
        $result->assertSee('History Anda');
    }

    public function testAdminPageLoads(): void
    {
        $result = $this->get('/admin');

        $result->assertStatus(200);
        $result->assertSee('Admin Console Pro');
        $result->assertDontSee('Rating Manual');
    }

    public function testLegacyHtmlRoutesStillLoad(): void
    {
        $this->get('/index.html')->assertStatus(200);
        $this->get('/player.html')->assertStatus(200);
        $this->get('/admin.html')->assertStatus(200);
    }
}
