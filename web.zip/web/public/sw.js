const CACHE_NAME = 'kstream-v3';
const assets = [
  './',
  './manifest.json'
];

// Tahap Install: Menyimpan aset statis ke dalam cache browser
self.addEventListener('install', e => {
  e.waitUntil(
    caches.open(CACHE_NAME).then(cache => {
      return cache.addAll(assets);
    })
  );
  self.skipWaiting();
});

self.addEventListener('activate', e => {
  e.waitUntil(
    caches.keys().then(keys => {
      return Promise.all(keys.filter(key => key !== CACHE_NAME).map(key => caches.delete(key)));
    })
  );
  self.clients.claim();
});

// Tahap Fetch: Mengatur strategi cache pintar
self.addEventListener('fetch', e => {
  const url = e.request.url;

  // ⚠️ KRTIKAL: Jika request menuju ke server Supabase, JANGAN gunakan cache!
  // Langsung ambil data real-time dari internet.
  if (url.includes('supabase.co')) {
    e.respondWith(fetch(e.request));
    return;
  }

  // Untuk aset statis web (HTML, CSS, Manifest), gunakan strategi Cache-First
  e.respondWith(
    caches.match(e.request).then(response => {
      return response || fetch(e.request);
    })
  );
});
