<?php

namespace App\Controllers;

class Pages extends BaseController
{
    public function home(): string
    {
        return $this->renderPage('home');
    }

    public function player(): string
    {
        return $this->renderPage('player');
    }

    public function admin(): string
    {
        return $this->renderPage('admin');
    }

    private function renderPage(string $page): string
    {
        helper('url');

        return view("pages/{$page}", [
            'supabaseUrl' => (string) env('supabase.url', ''),
            'supabaseKey' => (string) env('supabase.key', ''),
        ]);
    }
}
