<?php

use CodeIgniter\Router\RouteCollection;

/** @var RouteCollection $routes */
$routes->get('/', 'Pages::home', ['as' => 'home']);
$routes->get('player', 'Pages::player', ['as' => 'player']);
$routes->get('admin', 'Pages::admin', ['as' => 'admin']);

// Keep old bookmarks working after the static HTML migration.
$routes->get('index.html', 'Pages::home');
$routes->get('player.html', 'Pages::player');
$routes->get('admin.html', 'Pages::admin');
