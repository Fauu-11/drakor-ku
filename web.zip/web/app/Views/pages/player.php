<!DOCTYPE html>
<html lang="id" class="scroll-smooth">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Streaming Premium — K-STREAM</title>
    <meta name="theme-color" content="#020205">

    <script src="https://cdn.tailwindcss.com"></script>
    <script>
        tailwind.config = {
            theme: {
                extend: {
                    fontFamily: { sans: ['Inter', 'sans-serif'] },
                    colors: {
                        brand: { DEFAULT: '#ff2a74', hover: '#e11d62', glow: 'rgba(255, 42, 116, 0.2)' },
                        dark: { bg: '#020205', surface: '#0d0d14', border: '#1f1f2e', muted: '#64748b' }
                    }
                }
            }
        }
    </script>
    <link href="https://fonts.googleapis.com/css2?family=Inter:wght@400;500;600;700;800&display=swap" rel="stylesheet">
    <link rel="stylesheet" href="https://cdnjs.cloudflare.com/ajax/libs/font-awesome/6.4.0/css/all.min.css">
    <link rel="stylesheet" href="https://cdn.plyr.io/3.7.8/plyr.css">

    <style>
        :root {
            --plyr-color-main: #ff2a74;
            --plyr-video-background: #000;
            --plyr-video-radius: 22px;
        }
        body {
            background:
                radial-gradient(circle at 14% 0%, rgba(255,42,116,0.10), transparent 26rem),
                radial-gradient(circle at 88% 12%, rgba(34,211,238,0.06), transparent 24rem),
                #020205;
            color: #f8fafc;
        }
        .no-scrollbar::-webkit-scrollbar { display: none; }
        .no-scrollbar { -ms-overflow-style: none; scrollbar-width: none; }
        .surface {
            background: linear-gradient(180deg, rgba(18,18,30,0.96), rgba(10,10,18,0.96));
            border: 1px solid rgba(148,163,184,0.12);
            box-shadow: 0 18px 50px rgba(0,0,0,0.24), inset 0 1px 0 rgba(255,255,255,0.035);
        }
        .player-shell {
            position: relative;
            border-radius: 24px;
            padding: 1px;
            background: linear-gradient(135deg, rgba(255,42,116,0.55), rgba(34,211,238,0.20), rgba(255,255,255,0.05));
            box-shadow: 0 34px 90px rgba(0,0,0,0.55), 0 18px 42px rgba(255,42,116,0.10);
        }
        .player-shell::before {
            content: '';
            position: absolute;
            inset: 12% 8% -12%;
            z-index: -1;
            background: rgba(255,42,116,0.17);
            filter: blur(70px);
            opacity: 0.55;
            pointer-events: none;
        }
        .player-frame { overflow: hidden; border-radius: 23px; background: #000; }
        .plyr { border-radius: 23px; min-height: 240px; }
        .plyr__control--overlaid {
            width: 72px;
            height: 72px;
            background: linear-gradient(135deg, #ff2a74, #e11d62);
            box-shadow: 0 18px 42px rgba(255,42,116,0.36);
        }
        .plyr__controls {
            padding: 18px !important;
            background: linear-gradient(transparent, rgba(0,0,0,0.92)) !important;
        }
        .plyr--video .plyr__control:hover { background: rgba(255,42,116,0.92); }
        .plyr__progress__buffer { color: rgba(255,255,255,0.18); }
        .loading-ring {
            width: 42px;
            height: 42px;
            border: 3px solid rgba(255,255,255,0.16);
            border-top-color: #ff2a74;
            border-radius: 50%;
            animation: spin 0.75s linear infinite;
        }
        @keyframes spin { to { transform: rotate(360deg); } }
        .rating-star {
            color: #475569;
            transition: color 0.16s ease, transform 0.16s ease;
        }
        .rating-star:hover, .rating-star.active { color: #facc15; transform: translateY(-1px) scale(1.08); }
        .history-item, .comment-item { background: rgba(2,2,5,0.42); border: 1px solid rgba(148,163,184,0.10); }
        .history-item:hover { border-color: rgba(255,42,116,0.35); background: rgba(255,42,116,0.05); }
        .toast {
            position: fixed;
            right: 16px;
            bottom: 24px;
            z-index: 9999;
            display: flex;
            align-items: center;
            gap: 10px;
            min-width: 220px;
            max-width: 340px;
            padding: 12px 16px;
            border: 1px solid rgba(148,163,184,0.15);
            border-radius: 14px;
            background: #0d0d14;
            box-shadow: 0 18px 45px rgba(0,0,0,0.5);
            color: #f8fafc;
            font-size: 12px;
            font-weight: 600;
        }
        body.theater-mode .watch-grid { grid-template-columns: minmax(0, 1fr) !important; }
        body.theater-mode .watch-main { grid-column: 1 / -1; }
        body.theater-mode .watch-sidebar {
            display: grid;
            grid-template-columns: repeat(2, minmax(0, 1fr));
            align-items: start;
        }
        @media (max-width: 767px) {
            body { padding: 12px !important; }
            .plyr { min-height: 190px; }
            .plyr__controls { padding: 10px !important; }
            .plyr__control--overlaid { width: 58px; height: 58px; }
            body.theater-mode .watch-sidebar { grid-template-columns: minmax(0, 1fr); }
        }
    </style>
</head>
<body class="antialiased p-4 md:p-6 lg:p-10">

<div id="toast-container"></div>

<div class="max-w-[1500px] mx-auto space-y-6">
    <header class="flex flex-wrap items-center justify-between gap-3 pb-3 border-b border-dark-border/50">
        <button onclick="goBack()" class="inline-flex items-center gap-2 bg-dark-surface border border-dark-border px-4 py-2.5 rounded-xl text-xs font-semibold text-neutral-300 hover:text-brand hover:border-brand/40 transition-all">
            <i class="fa-solid fa-arrow-left"></i> Kembali
        </button>
        <div class="flex items-center gap-2">
            <span id="stream-status" class="inline-flex items-center gap-2 text-[10px] font-bold tracking-widest text-emerald-400 bg-emerald-500/10 border border-emerald-500/20 px-3 py-2 rounded-full uppercase">
                <i class="fa-solid fa-circle text-[6px] animate-pulse"></i> Siap Diputar
            </span>
            <button id="theater-mode-btn" onclick="toggleTheaterMode()" class="w-9 h-9 rounded-xl bg-dark-surface border border-dark-border text-neutral-300 hover:text-brand hover:border-brand/40 transition-all" title="Mode bioskop">
                <i class="fa-solid fa-expand"></i>
            </button>
        </div>
    </header>

    <div id="watch-layout" class="watch-grid grid grid-cols-1 lg:grid-cols-3 gap-6 items-start">
        <main class="watch-main lg:col-span-2 space-y-6">
            <section class="player-shell">
                <div class="player-frame relative">
                    <div id="player-loading" class="hidden absolute inset-0 z-40 bg-black/70 items-center justify-center">
                        <div class="loading-ring"></div>
                    </div>

                    <div id="autoplay-overlay" class="hidden absolute inset-0 bg-black/95 z-30 flex-col items-center justify-center gap-4">
                        <div class="text-center">
                            <span class="text-xs font-bold text-brand uppercase tracking-widest block mb-1">Episode Selesai</span>
                            <h3 id="autoplay-next-title" class="text-sm md:text-base font-bold text-white px-6 truncate max-w-md">Memutar Selanjutnya</h3>
                        </div>
                        <div class="w-14 h-14 flex items-center justify-center rounded-full border-4 border-brand bg-dark-surface">
                            <span id="autoplay-countdown-text" class="text-lg font-black text-white">5</span>
                        </div>
                        <div class="flex items-center gap-2">
                            <button onclick="cancelAutoplay()" class="px-4 py-2 bg-dark-border text-neutral-300 text-xs font-semibold rounded-xl">Batal</button>
                            <button id="autoplay-now-btn" class="px-4 py-2 bg-brand text-white text-xs font-bold rounded-xl">Putar Sekarang</button>
                        </div>
                    </div>

                    <div id="plyr-wrapper" class="block w-full">
                        <video id="player" playsinline controls preload="metadata"></video>
                    </div>

                    <div id="embed-wrapper" class="hidden w-full aspect-video bg-black">
                        <iframe
                            id="embed-player"
                            class="w-full h-full"
                            loading="lazy"
                            referrerpolicy="strict-origin-when-cross-origin"
                            allow="autoplay; encrypted-media; fullscreen; picture-in-picture"
                            allowfullscreen>
                        </iframe>
                    </div>
                </div>
            </section>

            <section class="surface p-5 md:p-6 rounded-3xl space-y-5">
                <div class="flex flex-wrap items-start justify-between gap-4">
                    <div class="min-w-0">
                        <h1 id="player-title" class="text-2xl md:text-3xl font-extrabold text-white tracking-tight truncate">Memuat Judul...</h1>
                        <p id="player-episode" class="text-brand font-semibold text-xs md:text-sm mt-1"></p>
                    </div>
                    <div class="flex items-center gap-2">
                        <button onclick="shareCurrentEpisode()" class="w-10 h-10 rounded-xl bg-dark-border/50 border border-dark-border text-neutral-300 hover:text-brand hover:border-brand/30 transition-all" title="Bagikan">
                            <i class="fa-solid fa-share-nodes"></i>
                        </button>
                        <button id="quick-next-btn" class="hidden text-xs font-bold bg-brand hover:bg-brand-hover text-white py-2.5 px-4 rounded-xl transition-all">
                            <i class="fa-solid fa-forward-step mr-1.5"></i> Berikutnya
                        </button>
                    </div>
                </div>

                <div class="flex flex-wrap items-center gap-3 text-xs text-dark-muted font-medium pt-3 border-t border-dark-border/50">
                    <span class="bg-brand/10 text-brand px-2 py-1 rounded font-bold uppercase tracking-wider text-[10px]">Streaming</span>
                    <span id="player-rating" class="text-yellow-400 font-bold"><i class="fa-solid fa-star mr-1"></i>Belum dinilai</span>
                    <span>•</span>
                    <span id="player-year">2026</span>
                    <span>•</span>
                    <span id="player-genre" class="text-neutral-300">Genre</span>
                </div>

                <div class="grid grid-cols-1 md:grid-cols-[1fr_auto] gap-5 items-start">
                    <div>
                        <h3 class="text-xs font-bold uppercase tracking-wider text-neutral-400 mb-2">Sinopsis Cerita</h3>
                        <p id="player-synopsis" class="text-sm text-neutral-400 leading-relaxed">Memuat deskripsi alur cerita...</p>
                    </div>
                    <div class="min-w-[220px] bg-dark-bg/60 border border-dark-border/60 rounded-2xl p-4">
                        <p class="text-xs font-bold text-white">Beri Rating Kamu</p>
                        <div id="user-rating-stars" class="flex items-center gap-1.5 text-xl mt-2" aria-label="Rating pengguna">
                            <button class="rating-star" data-rating="1" onclick="submitRating(1)" title="1 bintang"><i class="fa-solid fa-star"></i></button>
                            <button class="rating-star" data-rating="2" onclick="submitRating(2)" title="2 bintang"><i class="fa-solid fa-star"></i></button>
                            <button class="rating-star" data-rating="3" onclick="submitRating(3)" title="3 bintang"><i class="fa-solid fa-star"></i></button>
                            <button class="rating-star" data-rating="4" onclick="submitRating(4)" title="4 bintang"><i class="fa-solid fa-star"></i></button>
                            <button class="rating-star" data-rating="5" onclick="submitRating(5)" title="5 bintang"><i class="fa-solid fa-star"></i></button>
                        </div>
                        <p id="rating-summary" class="text-[11px] text-dark-muted mt-2">Belum ada rating pengguna.</p>
                    </div>
                </div>
            </section>

            <section class="space-y-3">
                <div class="flex items-center gap-2">
                    <span class="w-1 h-4 bg-brand rounded-full"></span>
                    <h2 class="text-base font-bold text-white">Mungkin Kamu Suka</h2>
                </div>
                <div id="recommendations-grid" class="grid grid-cols-2 sm:grid-cols-3 gap-4"></div>
            </section>

            <section class="surface rounded-3xl overflow-hidden">
                <div class="px-5 md:px-6 py-4 border-b border-dark-border/50">
                    <h2 class="text-base font-bold text-white"><i class="fa-regular fa-comments text-brand mr-2"></i>Komentar</h2>
                    <p class="text-xs text-dark-muted mt-1">Bagikan pendapat tentang tayangan atau episode ini.</p>
                </div>

                <div class="p-5 md:p-6 space-y-6">
                    <div id="comments-list" class="space-y-3">
                        <div class="text-xs text-dark-muted">Memuat komentar...</div>
                    </div>

                    <form id="comment-form" class="space-y-4 border-t border-dark-border/50 pt-5">
                        <div>
                            <label for="comment-message" class="text-xs font-semibold text-neutral-300">Komentar *</label>
                            <textarea id="comment-message" rows="5" maxlength="1200" required class="mt-2 w-full bg-dark-bg border border-dark-border rounded-2xl px-4 py-3 text-sm text-white focus:outline-none focus:border-brand resize-y" placeholder="Tulis komentar kamu..."></textarea>
                        </div>
                        <div class="grid grid-cols-1 sm:grid-cols-2 gap-4">
                            <div>
                                <label for="comment-name" class="text-xs font-semibold text-neutral-300">Nama *</label>
                                <input id="comment-name" type="text" maxlength="60" required class="mt-2 w-full bg-dark-bg border border-dark-border rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-brand">
                            </div>
                            <div>
                                <label for="comment-email" class="text-xs font-semibold text-neutral-300">Email</label>
                                <input id="comment-email" type="email" maxlength="160" class="mt-2 w-full bg-dark-bg border border-dark-border rounded-xl px-4 py-3 text-sm text-white focus:outline-none focus:border-brand">
                            </div>
                        </div>
                        <label class="inline-flex items-center gap-2 text-xs text-dark-muted cursor-pointer">
                            <input id="remember-commenter" type="checkbox" class="accent-brand">
                            Simpan nama dan email di browser ini.
                        </label>
                        <div>
                            <button id="comment-submit" type="submit" class="inline-flex items-center gap-2 bg-brand hover:bg-brand-hover text-white text-xs font-bold px-5 py-3 rounded-xl transition-all">
                                <i class="fa-solid fa-paper-plane"></i> Kirim Komentar
                            </button>
                        </div>
                    </form>
                </div>
            </section>
        </main>

        <aside class="watch-sidebar space-y-6">
            <section class="surface p-5 rounded-3xl space-y-4">
                <div class="flex items-center justify-between border-b border-dark-border/50 pb-3">
                    <h3 class="text-sm font-bold text-neutral-200"><i class="fa-solid fa-list-ol text-brand mr-2"></i>Pilih Episode</h3>
                    <span id="episode-count-badge" class="text-[10px] bg-dark-border text-dark-muted px-2 py-1 rounded-full font-bold">0 Bagian</span>
                </div>
                <div id="player-episode-list" class="grid grid-cols-2 sm:grid-cols-3 lg:grid-cols-2 xl:grid-cols-3 gap-2 max-h-80 overflow-y-auto pr-1 no-scrollbar"></div>
            </section>

            <section class="surface rounded-3xl overflow-hidden">
                <div class="flex items-center justify-between px-5 py-4 border-b border-dark-border/50">
                    <h3 class="text-sm font-bold text-neutral-200"><i class="fa-solid fa-clock-rotate-left text-brand mr-2"></i>History Anda</h3>
                    <button onclick="clearWatchHistory()" class="text-[10px] font-bold text-dark-muted hover:text-red-400">Hapus</button>
                </div>
                <div id="watch-history-list" class="max-h-[420px] overflow-y-auto no-scrollbar"></div>
            </section>
        </aside>
    </div>
</div>

<script src="https://cdn.jsdelivr.net/npm/@supabase/supabase-js@2"></script>
<script src="https://cdn.plyr.io/3.7.8/plyr.js"></script>

<script>
    const SUPABASE_URL = <?= json_encode($supabaseUrl, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    const SUPABASE_KEY = <?= json_encode($supabaseKey, JSON_HEX_TAG | JSON_HEX_AMP | JSON_HEX_APOS | JSON_HEX_QUOT) ?>;
    const HOME_URL = <?= json_encode(site_url('/')) ?>;
    const PLAYER_URL = <?= json_encode(site_url('player')) ?>;
    const _supabase = window.supabase.createClient(SUPABASE_URL, SUPABASE_KEY);

    const HISTORY_KEY = 'kstream_history';
    const PROGRESS_KEY = 'kstream_progress';
    const POSITION_KEY = 'kstream_playback_positions';
    const VISITOR_KEY = 'kstream_visitor_id';
    const USER_RATINGS_KEY = 'kstream_user_ratings';
    const COMMENTER_KEY = 'kstream_commenter';

    let currentDrama = null;
    let currentEpsIdx = 0;
    let autoplayInterval = null;
    let plyrPlayer = null;
    let dashPlayer = null;
    let commentsUseLocalFallback = false;
    let lastPositionSave = 0;

    const urlParams = new URLSearchParams(window.location.search);
    const dramaId = urlParams.get('id');
    const initialEps = Math.max(0, parseInt(urlParams.get('eps'), 10) || 0);
    const visitorId = getVisitorId();

    document.addEventListener('DOMContentLoaded', () => {
        plyrPlayer = new Plyr('#player', {
            controls: ['play-large', 'rewind', 'play', 'fast-forward', 'progress', 'current-time', 'duration', 'mute', 'volume', 'settings', 'pip', 'airplay', 'fullscreen'],
            settings: ['captions', 'quality', 'speed'],
            seekTime: 10,
            speed: { selected: 1, options: [0.5, 0.75, 1, 1.25, 1.5, 2] },
            ratio: '16:9',
            keyboard: { focused: true, global: false },
            tooltips: { controls: true, seek: true }
        });

        plyrPlayer.on('waiting', () => setPlayerLoading(true));
        plyrPlayer.on('playing', () => setPlayerLoading(false));
        plyrPlayer.on('canplay', () => setPlayerLoading(false));
        plyrPlayer.on('ended', () => startAutoplayCountdown());
        plyrPlayer.on('loadedmetadata', restorePlaybackPosition);
        plyrPlayer.on('timeupdate', savePlaybackPositionThrottled);

        document.getElementById('comment-form').addEventListener('submit', submitComment);
        restoreCommentIdentity();
        renderWatchHistory();
        loadVideoData();
    });

    window.addEventListener('beforeunload', savePlaybackPosition);
    document.addEventListener('visibilitychange', () => {
        if (document.visibilityState === 'hidden') savePlaybackPosition();
    });

    function getVisitorId() {
        let id = localStorage.getItem(VISITOR_KEY);
        if (!id) {
            id = window.crypto?.randomUUID?.() || `visitor-${Date.now()}-${Math.random().toString(16).slice(2)}`;
            localStorage.setItem(VISITOR_KEY, id);
        }
        return id;
    }

    function showToast(message, type = 'info') {
        const container = document.getElementById('toast-container');
        const toast = document.createElement('div');
        toast.className = 'toast';
        const icon = type === 'success' ? 'fa-circle-check text-emerald-400' : type === 'error' ? 'fa-circle-xmark text-red-400' : 'fa-circle-info text-brand';
        toast.innerHTML = `<i class="fa-solid ${icon}"></i><span></span>`;
        toast.querySelector('span').textContent = message;
        container.appendChild(toast);
        setTimeout(() => toast.remove(), 2800);
    }

    function setPlayerLoading(isLoading) {
        const loader = document.getElementById('player-loading');
        loader.classList.toggle('hidden', !isLoading);
        loader.classList.toggle('flex', isLoading);
        document.getElementById('stream-status').innerHTML = isLoading
            ? '<i class="fa-solid fa-circle-notch fa-spin"></i> Memuat'
            : '<i class="fa-solid fa-circle text-[6px] animate-pulse"></i> Siap Diputar';
    }

    function goBack() { window.location.href = HOME_URL; }

    async function loadVideoData() {
        if (!dramaId) return goBack();
        setPlayerLoading(true);
        try {
            const { data, error } = await _supabase.from('drakor').select('*').eq('id', dramaId).single();
            if (error || !data) throw error || new Error('Data media tidak ditemukan.');
            currentDrama = data;
            await setupPlayer(Math.min(initialEps, Math.max(0, currentDrama.episodes.length - 1)));
            await Promise.allSettled([fetchRecommendations(), loadUserRating(), loadComments()]);
        } catch (error) {
            console.error(error);
            showToast('Gagal mengambil data media.', 'error');
            setTimeout(goBack, 1200);
        } finally {
            setPlayerLoading(false);
        }
    }

    async function fetchRecommendations() {
        const { data, error } = await _supabase.from('drakor').select('id,title,image').neq('id', dramaId).limit(3);
        if (error || !data) return;
        const grid = document.getElementById('recommendations-grid');
        grid.innerHTML = '';
        data.forEach(show => {
            const card = document.createElement('button');
            card.className = 'group text-left bg-dark-surface border border-dark-border p-2 rounded-2xl hover:border-brand/40 transition-all';
            card.onclick = () => { window.location.href = `${PLAYER_URL}?id=${encodeURIComponent(show.id)}&eps=0`; };
            const image = document.createElement('img');
            image.src = show.image || '';
            image.alt = show.title;
            image.loading = 'lazy';
            image.className = 'w-full aspect-[3/4] object-cover rounded-xl group-hover:scale-[1.02] transition-transform';
            const title = document.createElement('h4');
            title.className = 'text-xs font-bold truncate text-white mt-2 px-1';
            title.textContent = show.title;
            card.append(image, title);
            grid.appendChild(card);
        });
    }

    function parseYouTubeId(url) {
        const match = url.match(/^.*(youtu.be\/|v\/|u\/\w\/|embed\/|watch\?v=|&v=)([^#&?]*).*/);
        return match && match[2].length === 11 ? match[2] : null;
    }

    function ensureDashJs() {
        if (window.dashjs) return Promise.resolve(window.dashjs);
        return new Promise((resolve, reject) => {
            const existing = document.getElementById('dashjs-script');
            if (existing) {
                existing.addEventListener('load', () => resolve(window.dashjs), { once: true });
                existing.addEventListener('error', reject, { once: true });
                return;
            }
            const script = document.createElement('script');
            script.id = 'dashjs-script';
            script.src = 'https://cdn.dashjs.org/latest/dash.all.min.js';
            script.async = true;
            script.onload = () => resolve(window.dashjs);
            script.onerror = reject;
            document.head.appendChild(script);
        });
    }

    async function setupPlayer(epsIdx) {
        if (!currentDrama?.episodes?.[epsIdx]) return;
        cancelAutoplay();
        savePlaybackPosition();
        currentEpsIdx = epsIdx;
        setPlayerLoading(true);

        const episodeData = currentDrama.episodes[epsIdx];
        const videoUrl = episodeData.videoUrl || '';

        document.getElementById('player-title').textContent = currentDrama.title;
        document.getElementById('player-episode').textContent = `Sedang Memutar: ${episodeData.epsName}`;
        document.getElementById('player-year').textContent = currentDrama.year || '2026';
        document.getElementById('player-genre').textContent = currentDrama.genre || 'K-Drama';
        document.getElementById('player-synopsis').textContent = currentDrama.synopsis || 'Tidak ada deskripsi.';
        document.getElementById('episode-count-badge').textContent = `${currentDrama.episodes.length} Bagian`;
        document.title = `${currentDrama.title} — ${episodeData.epsName} | K-STREAM`;

        if (dashPlayer) {
            dashPlayer.reset();
            dashPlayer = null;
        }

        const plyrWrapper = document.getElementById('plyr-wrapper');
        const embedWrapper = document.getElementById('embed-wrapper');
        const iframeEl = document.getElementById('embed-player');
        const videoEl = document.getElementById('player');
        iframeEl.src = '';
        videoEl.poster = currentDrama.image || '';

        try {
            if (videoUrl.includes('embed') || videoUrl.includes('/embed/') || videoUrl.includes('abyss') || videoUrl.includes('kisskh')) {
                plyrPlayer.pause();
                plyrWrapper.classList.add('hidden');
                embedWrapper.classList.remove('hidden');
                iframeEl.src = videoUrl;
                setPlayerLoading(false);
            } else if (videoUrl.includes('.mpd') || videoUrl.includes('dash')) {
                embedWrapper.classList.add('hidden');
                plyrWrapper.classList.remove('hidden');
                await ensureDashJs();
                dashPlayer = window.dashjs.MediaPlayer().create();
                dashPlayer.initialize(videoEl, videoUrl, true);
            } else if (videoUrl.includes('youtube.com') || videoUrl.includes('youtu.be')) {
                embedWrapper.classList.add('hidden');
                plyrWrapper.classList.remove('hidden');
                plyrPlayer.source = { type: 'video', sources: [{ src: parseYouTubeId(videoUrl), provider: 'youtube' }], poster: currentDrama.image || '' };
            } else {
                embedWrapper.classList.add('hidden');
                plyrWrapper.classList.remove('hidden');
                plyrPlayer.source = { type: 'video', sources: [{ src: videoUrl, type: 'video/mp4' }], poster: currentDrama.image || '' };
                setTimeout(() => plyrPlayer.play().catch(() => {}), 350);
            }
        } catch (error) {
            console.error(error);
            setPlayerLoading(false);
            showToast('Sumber video gagal dimuat.', 'error');
        }

        markEpisodeWatched();
        recordWatchHistory();
        renderEpisodeList();
        renderWatchHistory();
    }

    function getProgressData() {
        return JSON.parse(localStorage.getItem(PROGRESS_KEY) || '{}');
    }

    function markEpisodeWatched() {
        const progress = getProgressData();
        if (!progress[currentDrama.id]) progress[currentDrama.id] = {};
        progress[currentDrama.id][currentEpsIdx] = true;
        localStorage.setItem(PROGRESS_KEY, JSON.stringify(progress));

        localStorage.setItem('lastWatched', JSON.stringify({
            cloudId: currentDrama.id,
            epsIdx: currentEpsIdx,
            label: `${currentDrama.title} — ${currentDrama.episodes[currentEpsIdx].epsName}`,
            progress: Math.round(((currentEpsIdx + 1) / currentDrama.episodes.length) * 100)
        }));
    }

    function renderEpisodeList() {
        const progress = getProgressData();
        const list = document.getElementById('player-episode-list');
        list.innerHTML = '';

        currentDrama.episodes.forEach((episode, idx) => {
            const watched = Boolean(progress[currentDrama.id]?.[idx]);
            const button = document.createElement('button');
            button.className = idx === currentEpsIdx
                ? 'w-full py-3 bg-brand text-white text-xs font-bold rounded-xl border border-brand'
                : `w-full py-3 text-xs font-semibold rounded-xl border transition-all ${watched ? 'border-brand/30 text-brand bg-brand/5' : 'border-dark-border text-neutral-400 bg-dark-surface/50 hover:border-brand/50 hover:text-white'}`;
            button.innerHTML = `<span></span>${watched && idx !== currentEpsIdx ? ' <i class="fa-solid fa-check text-[9px]"></i>' : ''}`;
            button.querySelector('span').textContent = episode.epsName;
            button.onclick = () => setupPlayer(idx);
            list.appendChild(button);
        });

        const quickNext = document.getElementById('quick-next-btn');
        if (currentDrama.episodes[currentEpsIdx + 1]) {
            quickNext.classList.remove('hidden');
            quickNext.onclick = startAutoplayCountdown;
        } else {
            quickNext.classList.add('hidden');
        }
    }

    function getPlaybackPositions() {
        return JSON.parse(localStorage.getItem(POSITION_KEY) || '{}');
    }

    function getPositionId() {
        return currentDrama ? `${currentDrama.id}:${currentEpsIdx}` : '';
    }

    function savePlaybackPositionThrottled() {
        const now = Date.now();
        if (now - lastPositionSave < 8000) return;
        lastPositionSave = now;
        savePlaybackPosition();
    }

    function savePlaybackPosition() {
        if (!currentDrama || !plyrPlayer || !Number.isFinite(plyrPlayer.currentTime) || plyrPlayer.currentTime < 2) return;
        const positions = getPlaybackPositions();
        positions[getPositionId()] = {
            time: Math.floor(plyrPlayer.currentTime),
            duration: Math.floor(plyrPlayer.duration || 0),
            updatedAt: Date.now()
        };
        localStorage.setItem(POSITION_KEY, JSON.stringify(positions));
    }

    function restorePlaybackPosition() {
        const saved = getPlaybackPositions()[getPositionId()];
        if (!saved || saved.time < 5) return;
        if (plyrPlayer.duration && saved.time < plyrPlayer.duration - 15) {
            plyrPlayer.currentTime = saved.time;
            showToast(`Melanjutkan dari ${formatDuration(saved.time)}`);
        }
    }

    function formatDuration(totalSeconds) {
        const minutes = Math.floor(totalSeconds / 60);
        const seconds = Math.floor(totalSeconds % 60).toString().padStart(2, '0');
        return `${minutes}:${seconds}`;
    }

    function recordWatchHistory() {
        if (!currentDrama) return;
        const episode = currentDrama.episodes[currentEpsIdx];
        const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]')
            .filter(item => !(String(item.cloudId) === String(currentDrama.id) && item.epsIdx === currentEpsIdx));
        history.unshift({
            cloudId: currentDrama.id,
            epsIdx: currentEpsIdx,
            title: currentDrama.title,
            episode: episode.epsName,
            year: currentDrama.year || '',
            image: currentDrama.image || '',
            watchedAt: Date.now()
        });
        localStorage.setItem(HISTORY_KEY, JSON.stringify(history.slice(0, 20)));
    }

    function renderWatchHistory() {
        const list = document.getElementById('watch-history-list');
        const history = JSON.parse(localStorage.getItem(HISTORY_KEY) || '[]');
        list.innerHTML = '';
        if (!history.length) {
            list.innerHTML = '<div class="p-5 text-xs text-dark-muted">Belum ada riwayat tontonan.</div>';
            return;
        }
        history.forEach(item => {
            const button = document.createElement('button');
            button.className = 'history-item w-full p-4 text-left transition-all border-x-0 border-t-0';
            button.onclick = () => {
                window.location.href = `${PLAYER_URL}?id=${encodeURIComponent(item.cloudId)}&eps=${item.epsIdx}`;
            };
            const title = document.createElement('p');
            title.className = 'text-xs text-neutral-200 leading-relaxed';
            title.textContent = `${item.title}${item.year ? ` (${item.year})` : ''} ${item.episode}`;
            const time = document.createElement('p');
            time.className = 'text-[10px] italic text-dark-muted mt-1';
            time.textContent = relativeTime(item.watchedAt);
            button.append(title, time);
            list.appendChild(button);
        });
    }

    function clearWatchHistory() {
        localStorage.removeItem(HISTORY_KEY);
        renderWatchHistory();
        showToast('Riwayat tontonan dihapus.');
    }

    function relativeTime(value) {
        const timestamp = typeof value === 'number' ? value : new Date(value).getTime();
        const seconds = Math.max(1, Math.floor((Date.now() - timestamp) / 1000));
        if (seconds < 60) return 'baru saja';
        const minutes = Math.floor(seconds / 60);
        if (minutes < 60) return `${minutes} menit lalu`;
        const hours = Math.floor(minutes / 60);
        if (hours < 24) return `${hours} jam lalu`;
        const days = Math.floor(hours / 24);
        if (days < 30) return `${days} hari lalu`;
        return new Date(timestamp).toLocaleDateString('id-ID');
    }

    async function loadUserRating() {
        const localRatings = JSON.parse(localStorage.getItem(USER_RATINGS_KEY) || '{}');
        setSelectedRating(Number(localRatings[dramaId] || 0));

        const { data, error } = await _supabase
            .from('drakor_ratings')
            .select('rating,visitor_id')
            .eq('drakor_id', dramaId);

        if (error) {
            renderRatingSummary(Number(localRatings[dramaId] || 0), localRatings[dramaId] ? 1 : 0);
            return;
        }

        const ratings = data || [];
        if (!ratings.length && localRatings[dramaId]) {
            renderRatingSummary(Number(localRatings[dramaId]), 1);
            return;
        }
        const average = ratings.length ? ratings.reduce((sum, item) => sum + Number(item.rating || 0), 0) / ratings.length : 0;
        const ownRating = ratings.find(item => item.visitor_id === visitorId)?.rating;
        if (ownRating) setSelectedRating(Number(ownRating));
        renderRatingSummary(average, ratings.length);
    }

    function renderRatingSummary(average, count) {
        const ratingLabel = count ? `${average.toFixed(1)} (${count} pengguna)` : 'Belum dinilai';
        document.getElementById('player-rating').innerHTML = `<i class="fa-solid fa-star mr-1"></i>${ratingLabel}`;
        document.getElementById('rating-summary').textContent = count
            ? `Rata-rata ${average.toFixed(1)} dari ${count} pengguna.`
            : 'Jadilah pengguna pertama yang memberi rating.';
    }

    function setSelectedRating(value) {
        document.querySelectorAll('.rating-star').forEach(star => {
            star.classList.toggle('active', Number(star.dataset.rating) <= value);
        });
    }

    async function submitRating(value) {
        if (!currentDrama) return;
        const localRatings = JSON.parse(localStorage.getItem(USER_RATINGS_KEY) || '{}');
        localRatings[currentDrama.id] = value;
        localStorage.setItem(USER_RATINGS_KEY, JSON.stringify(localRatings));
        setSelectedRating(value);

        const { error } = await _supabase.from('drakor_ratings').upsert([{
            drakor_id: currentDrama.id,
            visitor_id: visitorId,
            rating: value,
            updated_at: new Date().toISOString()
        }], { onConflict: 'drakor_id,visitor_id' });

        if (error) {
            console.warn('Rating disimpan lokal karena tabel komunitas belum tersedia.', error);
            renderRatingSummary(value, 1);
            showToast('Rating disimpan di perangkat ini.');
            return;
        }

        showToast('Terima kasih atas rating kamu!', 'success');
        await loadUserRating();
    }

    function getLocalCommentsKey() {
        return `kstream_comments_${dramaId}`;
    }

    async function loadComments() {
        const { data, error } = await _supabase
            .from('drakor_comments')
            .select('id,name,comment,episode_index,created_at')
            .eq('drakor_id', dramaId)
            .eq('status', 'published')
            .order('created_at', { ascending: false })
            .limit(50);

        if (error) {
            commentsUseLocalFallback = true;
            renderComments(JSON.parse(localStorage.getItem(getLocalCommentsKey()) || '[]'));
            return;
        }

        commentsUseLocalFallback = false;
        const localComments = JSON.parse(localStorage.getItem(getLocalCommentsKey()) || '[]');
        const comments = [...localComments, ...(data || [])]
            .sort((a, b) => new Date(b.created_at) - new Date(a.created_at));
        renderComments(comments);
    }

    function renderComments(comments) {
        const list = document.getElementById('comments-list');
        list.innerHTML = '';
        if (!comments.length) {
            list.innerHTML = '<div class="text-xs text-dark-muted">Belum ada komentar. Mulai diskusi pertama.</div>';
            return;
        }

        comments.forEach(item => {
            const article = document.createElement('article');
            article.className = 'comment-item rounded-2xl p-4';
            const header = document.createElement('div');
            header.className = 'flex flex-wrap items-center justify-between gap-2';
            const name = document.createElement('strong');
            name.className = 'text-xs text-brand';
            name.textContent = item.name || 'Pengguna';
            const meta = document.createElement('span');
            meta.className = 'text-[10px] text-dark-muted';
            const episodeLabel = item.episode_index !== null && item.episode_index !== undefined
                ? ` • ${currentDrama?.episodes?.[Number(item.episode_index)]?.epsName || `Episode ${Number(item.episode_index) + 1}`}`
                : '';
            meta.textContent = `${relativeTime(item.created_at)}${episodeLabel}`;
            const message = document.createElement('p');
            message.className = 'text-sm text-neutral-300 leading-relaxed mt-3 whitespace-pre-wrap break-words';
            message.textContent = item.comment;
            header.append(name, meta);
            article.append(header, message);
            list.appendChild(article);
        });
    }

    async function submitComment(event) {
        event.preventDefault();
        if (!currentDrama) return;

        const nameInput = document.getElementById('comment-name');
        const emailInput = document.getElementById('comment-email');
        const messageInput = document.getElementById('comment-message');
        const remember = document.getElementById('remember-commenter').checked;
        const submitButton = document.getElementById('comment-submit');
        const name = nameInput.value.trim();
        const email = emailInput.value.trim();
        const comment = messageInput.value.trim();

        if (!name || !comment) {
            showToast('Nama dan komentar wajib diisi.', 'error');
            return;
        }

        if (remember) {
            localStorage.setItem(COMMENTER_KEY, JSON.stringify({ name, email }));
        } else {
            localStorage.removeItem(COMMENTER_KEY);
        }

        submitButton.disabled = true;
        submitButton.classList.add('opacity-60');

        const payload = {
            drakor_id: currentDrama.id,
            episode_index: currentEpsIdx,
            visitor_id: visitorId,
            name,
            email: email || null,
            comment,
            status: 'published'
        };

        let savedLocally = commentsUseLocalFallback;
        if (!commentsUseLocalFallback) {
            const { error } = await _supabase.from('drakor_comments').insert([payload]);
            savedLocally = Boolean(error);
            if (error) console.warn('Komentar disimpan lokal karena tabel komunitas belum tersedia.', error);
        }

        if (savedLocally) {
            commentsUseLocalFallback = true;
            const comments = JSON.parse(localStorage.getItem(getLocalCommentsKey()) || '[]');
            comments.unshift({ ...payload, id: `local-${Date.now()}`, created_at: new Date().toISOString() });
            localStorage.setItem(getLocalCommentsKey(), JSON.stringify(comments.slice(0, 50)));
            renderComments(comments);
            showToast('Komentar disimpan di perangkat ini.');
        } else {
            await loadComments();
            showToast('Komentar berhasil dikirim!', 'success');
        }

        messageInput.value = '';
        submitButton.disabled = false;
        submitButton.classList.remove('opacity-60');
    }

    function restoreCommentIdentity() {
        const commenter = JSON.parse(localStorage.getItem(COMMENTER_KEY) || 'null');
        if (!commenter) return;
        document.getElementById('comment-name').value = commenter.name || '';
        document.getElementById('comment-email').value = commenter.email || '';
        document.getElementById('remember-commenter').checked = true;
    }

    async function shareCurrentEpisode() {
        if (!currentDrama) return;
        const shareData = {
            title: `${currentDrama.title} — ${currentDrama.episodes[currentEpsIdx].epsName}`,
            text: `Tonton ${currentDrama.title} di K-STREAM`,
            url: window.location.href
        };
        try {
            if (navigator.share) await navigator.share(shareData);
            else {
                await navigator.clipboard.writeText(window.location.href);
                showToast('Link episode disalin.', 'success');
            }
        } catch (error) {
            if (error?.name !== 'AbortError') showToast('Link tidak dapat dibagikan.', 'error');
        }
    }

    function toggleTheaterMode() {
        document.body.classList.toggle('theater-mode');
        const active = document.body.classList.contains('theater-mode');
        document.querySelector('#theater-mode-btn i').className = active ? 'fa-solid fa-compress' : 'fa-solid fa-expand';
    }

    function startAutoplayCountdown() {
        const nextIdx = currentEpsIdx + 1;
        if (!currentDrama?.episodes?.[nextIdx]) return;
        if (plyrPlayer.fullscreen.active) plyrPlayer.fullscreen.exit();

        const overlay = document.getElementById('autoplay-overlay');
        const countdownText = document.getElementById('autoplay-countdown-text');
        document.getElementById('autoplay-next-title').textContent = `Memutar Selanjutnya: ${currentDrama.episodes[nextIdx].epsName}`;
        overlay.classList.remove('hidden');
        overlay.classList.add('flex');

        let seconds = 5;
        countdownText.textContent = seconds;
        clearInterval(autoplayInterval);
        autoplayInterval = setInterval(() => {
            seconds -= 1;
            countdownText.textContent = seconds;
            if (seconds <= 0) {
                clearInterval(autoplayInterval);
                cancelAutoplay();
                setupPlayer(nextIdx);
            }
        }, 1000);

        document.getElementById('autoplay-now-btn').onclick = () => {
            cancelAutoplay();
            setupPlayer(nextIdx);
        };
    }

    function cancelAutoplay() {
        clearInterval(autoplayInterval);
        const overlay = document.getElementById('autoplay-overlay');
        overlay.classList.add('hidden');
        overlay.classList.remove('flex');
    }
</script>
</body>
</html>
